# JARVIS Android

A starter Android project for building a personal JARVIS-style assistant.

## Current version
- Basic JARVIS screen
- Start button
- Ready for voice input, AI responses, and Android actions in later steps

## Package
`com.anaslucci.jarvis`

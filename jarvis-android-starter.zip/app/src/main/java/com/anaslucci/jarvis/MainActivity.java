package com.anaslucci.jarvis;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView status = findViewById(R.id.status);
        Button button = findViewById(R.id.startButton);

        button.setOnClickListener(v ->
            status.setText("JARVIS is ready. What can I do for you?")
        );
    }
}
